void enroquar_largo.c(char tablero[8][8])
{
return;
}
