void coronar_peon(char tablero, char entrada, int x, int y);
