#include "situacion_1.h"
#include "situacion_2.h"
#include "situacion_3.h"
#include "situacion_4.h"
#include "situacion_5.h"
int
dar_jaque (char tablero[8][8], int coor_x, int coor_y);
