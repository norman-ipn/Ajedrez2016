#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void
menu_jugador (void);

void
manual (void);

void
iniciar_sesion ();

int
main (void);
