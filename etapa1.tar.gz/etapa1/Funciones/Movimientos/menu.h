#include <stdio.h>
#include <stdlib.h>

void
pausa (void);

void
regresar_mov (char tablero [8][8], char copia[8][8]);

void
colocar_piezas (char a[8][8]);

void
jugar (char a[8][8]);

int
nuevo_juego (void);

int
cargar_partida (void);

int
manual (void);

int
menu (void);

int
main(void);
