void
inicializar_piezas_mov (char piezas_mov[1000])
{
  int i = 0;
  while (i < 1000)
    {
      piezas_mov[i] = '0';
      i = i + 1;

    }


}
