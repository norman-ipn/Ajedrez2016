void
piezas_movidas (char pieza, char piezas_mov[1000]);
