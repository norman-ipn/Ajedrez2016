void inicializar (char tablero[8][8]);
