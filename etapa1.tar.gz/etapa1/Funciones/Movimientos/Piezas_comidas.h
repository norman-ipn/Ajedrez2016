void
anadir (char arreglo[16], int b, int pos);

void
pcomida (int a, int color);
