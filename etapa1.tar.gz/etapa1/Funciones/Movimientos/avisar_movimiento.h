int
avisar_movimiento (char historial[100], char pieza);
