int (char tablero[8][8])
{
return 0;
}
