void
piezas_movidas (char pieza, char piezas_mov[1000])
{
  if (piezas_mov[0] == '0')
    {
      inicializar_piezas_mov (piezas_mov);
    }
  int i = 0;
  while (piezas_mov[i] != '0')
    {
      i = i + 1;

    }
  piezas_mov[i] == pieza;



}
