#include <stdio.h>
#include <stdlib.h>




char
amigo_o_enemigo(char i, char j);


int
mover_pieza ();

