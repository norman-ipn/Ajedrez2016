int
validar_movimientos_continuos(char tablero[8][8], int direccion[4][2], int x1, int y1, int x2, int y2);
