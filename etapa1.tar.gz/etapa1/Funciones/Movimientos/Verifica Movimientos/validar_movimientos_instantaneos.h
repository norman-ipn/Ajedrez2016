int
validar_movimientos_instantaneos (char tablero[8][8], int direccion[8][2],
				  int x1, int y1, int x2, int y2);

#include "coordenada_valida.h"

#include "color_pieza.h"
