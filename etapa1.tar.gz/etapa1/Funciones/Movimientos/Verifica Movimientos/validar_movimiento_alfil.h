int validar_movimiento_alfil(char tablero[8][8], int x1,int y1, int x2, int y2);
