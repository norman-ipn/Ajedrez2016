int
mover_horizontalmente (char tablero[8][8], int columnai, int filai,
                       int columnaf, int filaf, char negra, char blanca);
#include <stdio.h>
