int 
revisar_casilla_vacia (char tablero[8][8], int i, int j);
