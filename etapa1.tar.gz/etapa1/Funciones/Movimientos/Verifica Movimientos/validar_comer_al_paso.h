int validar_comer_al_paso (char tablero[8][8], int cord_x, int cord_y);
