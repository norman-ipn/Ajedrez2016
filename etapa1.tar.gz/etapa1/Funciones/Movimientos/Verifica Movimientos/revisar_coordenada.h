int
revisar_coordenada (int pos_i_x, int pos_i_y, char tablero[8][8]);
