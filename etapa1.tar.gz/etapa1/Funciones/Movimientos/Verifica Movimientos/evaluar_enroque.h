void 
evaluar_enroque(char tablero[8][8], int turno, int pos_torre_x, int pos_torre_y);

#include "validar_enroques.h" 

/* el archivo .h es el que lleva las directivas de preprocesamiento (#include) */
