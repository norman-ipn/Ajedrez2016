int
casilla_atacada (char tablero[8][8], int posicionini_x, int posicionini_y,
		 int posicionevaluar_x, int posicionevaluar_y);
