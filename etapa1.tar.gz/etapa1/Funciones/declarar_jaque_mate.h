int
declarar_jaque_mate (char tablero[8][8], char pieza_jaque,
		     int coordenadas_pieza[2], int rey[2]);
