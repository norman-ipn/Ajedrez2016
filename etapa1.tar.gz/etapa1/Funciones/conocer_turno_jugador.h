int
conocer_turno_jugador(int turno);
