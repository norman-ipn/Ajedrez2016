#include "verificar_casilla.h"
int
situacion_2 (char tablero[8][8], int coor_x, int coor_y);
