/* Observacion. No existe la funcion verificar casilla en los archivos subidos */
#include "verificar_casilla.h"
int
situacion_1 (char tablero[8][8], int coor_x, int coor_y);
