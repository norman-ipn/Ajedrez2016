void continuar_partida (char archivo[100]);

void guardar_mov (char a[5], int i);

void actualiza_historial (int resultado, char mensaje_salida[100]);

int guarda_partida (char tablero[8][8]);

int recupera_partida (char tablero[8][8]);
