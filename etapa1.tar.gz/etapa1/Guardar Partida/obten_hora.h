void obten_hora();
