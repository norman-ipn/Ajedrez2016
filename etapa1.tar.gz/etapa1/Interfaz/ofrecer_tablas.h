int
ofrecer_tablas(tablero[8][8]);
