#include<stdio.h>

#include <string.h>



int
primera_pantalla (void)
{

  /*Programa que muestra al usuario la bienvenida al ajedrez */

  char nombre[25], opc = 0;

  int variable = 0, i, repetir = 0;

  float F = 0, m = 0, a = 0;

  do

    {

      while (opc < 1)

	{

	  system ("color B5");

	  printf ("Bienvenido a su sistema: \n\n");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   *********   ***   ***   *** \n");

	  printf ("\n\n\tCargando...");



	  i = 0;

	  do
	    {

	      i = i + 1;

	      i = i - 1;

	      i = i + 1;



	    }
	  while (i < 100000000);

	  opc = opc + 1;



	  system ("cls");

	}

      opc = 0;

      while (opc < 1)

	{

	  system ("color A4");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   *********   ***   ***   *** \n");

	  printf ("\n\n\tCargando...");

	  i = 0;

	  do
	    {

	      i = i + 1;

	      i = i - 1;

	      i = i + 1;

	    }
	  while (i < 100000000);;

	  opc = opc + 1;



	  system ("cls");

	}

      opc = 0;

      while (opc < 1)

	{

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   *********   ***   ***   *** \n");

	  printf ("\n\n\tCargando...");

	  i = 0;

	  do
	    {

	      i = i + 1;

	      i = i - 1;

	      i = i + 1;



	    }
	  while (i < 100000000);

	  opc = opc + 1;



	  system ("cls");

	}

      opc = 0;

      while (opc < 1)

	{

	  system ("color B5");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   *********   ***   ***   *** \n");

	  printf ("\n\n\tCargando...");

	  i = 0;

	  do
	    {

	      i = i + 1;

	      i = i - 1;

	      i = i + 1;



	    }
	  while (i < 100000000);;

	  opc = opc + 1;



	  system ("cls");

	}

      opc = 0;

      while (opc < 1)

	{

	  system ("color A4");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t*********   *********   *********   *********   *************** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   ***   ***   ***   ***   *** \n");

	  printf
	    ("\t*********   *********   *********   *********   ***   ***   *** \n");

	  printf ("\n\n\tCargando...");

	  i = 0;

	  do
	    {

	      i = i + 1;

	      i = i - 1;

	      i = i + 1;



	    }
	  while (i < 100000000);

	  opc = opc + 1;



	  system ("cls");

	}



      opc = opc + 1;



      system ("cls");

      repetir = repetir + 1;

    }
  while (repetir < 1);

  system ("color 70");

  system ("color A4");

  printf
    ("\t*********   *********   *********   *********   *************** \n");

  printf
    ("\t*********   *********   *********   *********   *************** \n");

  printf
    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

  printf
    ("\t***         ***         ***         ***   ***   ***   ***   *** \n");

  printf
    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

  printf
    ("\t*********   *********   ***         ***   ***   ***   ***   *** \n");

  printf
    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

  printf
    ("\t***               ***   ***         ***   ***   ***   ***   *** \n");

  printf
    ("\t*********   *********   *********   ***   ***   ***   ***   *** \n");

  printf
    ("\t*********   *********   *********   *********   ***   ***   *** \n");

  printf ("\n\n\tCargando...");

  i = 0;

  do
    {

      i = i + 1;

      i = i - 1;

      i = i + 1;





    }
  while (i < 10000000);



  printf
    ("\n\n\tAjedrez ESCOM esta cargando. Bienvenido.\n\n\n\tAjedrez est%c optimizado para cubrir tus necesidades de juego.",
     160, 160);

  printf
    ("\n\tAjedrez ESCOM pretende innovar las funciones de una aplicaci%cn b%csica."),
    162, 160;

  printf
    ("\n\n\t(Presione enter para continuar y adentrarse al nuevo mundo de los juegos.)");



}

int
main (void)
{
  int color = 0;
  color = primera_pantalla ();
}
