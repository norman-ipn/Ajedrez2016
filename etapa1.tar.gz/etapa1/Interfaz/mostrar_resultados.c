#include "mostrar_resultados.h"

void
mostrar_resultados (int num_jugador)	/*Número del jugador que ha ganado */
{


  printf ("El jugador %d ha ganado esta partida, Felicidades  ", num_jugador);

  printf ("\n+88_______________________________");
  printf ("\n_+880_____________________________");
  printf ("\n_++88_____________________________");
  printf ("\n_++88_____________________________");
  printf ("\n__+880_________________________++_");
  printf ("\n__+888________________________+88_");
  printf ("\n__++880______________________+88__");
  printf ("\n__++888_____+++88__________+++8__");
  printf ("\n__++8888__+++8880++88____+++88___");
  printf ("\n__+++8888+++8880++8888__++888____");
  printf ("\n___++888++8888+++888888++888_____");
  printf ("\n___++88++8888++8888888++888______");
  printf ("\n___++++++888888888888888888______");
  printf ("\n____++++++88888888888888888______");
  printf ("\n____++++++++000888888888888______");
  printf ("\n_____+++++++000088888888888______");
  printf ("\n______+++++++00088888888888______");
  printf ("\n_______+++++++088888888888_______");
  printf ("\n_______+++++++088888888888_______");
  printf ("\n________+++++++8888888888________");
  printf ("\n________+++++++0088888888________");
  printf ("\n________++++++0088888888_________");
  udhist ();
}

/*Aqui yo creo se tendria que mandar a llamar lo que es el almacenado de partidas y el menu yo creo */
/*Propongo que se cambie el nombre de la función del historial por algo que se entienda sin tener que leer los comentarios*/
