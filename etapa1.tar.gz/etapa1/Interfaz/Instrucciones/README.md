﻿# Ajedrez2016

En esta sección se encuentra el codigo que se encarga de mostrar graficamente las intrucciones del ajedrez, asi como los menus de esas intrucciones.

ESTE CODIGO ESTA COMPLETO