#include <stdio.h>
void
reglas_peon (void);
