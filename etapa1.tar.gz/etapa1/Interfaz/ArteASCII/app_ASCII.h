
/*
*********************
COMO USAR ESTE CODIGO
*********************
Este codigo carga una direccion de memoria que contiene la letra en arte ASCII,
recibe una matriz de 7x5 y la llena con la letra solicitada, y un char en minuscula de la letra a usar
El ultimo cambio fue propiedad de AcardiaWolfman y asocidos


*/
void
Igualarletra (char letra[7][5], char array[7][5]);

void
sp (char letra[7][5]);

void
ex (char letra[7][5]);

void
num1 (char letra[7][5]);

void
num2 (char letra[7][5]);

void
letraA (char letra[7][5]);

void
letraB (char letra[7][5]);

void
letraC (char letra[7][5]);

void
letraD (char letra[7][5]);

void
letraE (char letra[7][5]);

void
letraF (char letra[7][5]);

void
letraG (char letra[7][5]);

void
letraH (char letra[7][5]);

void
letraI (char letra[7][5]);

void
letraJ (char letra[7][5]);

void
letraK (char letra[7][5]);

void
letraL (char letra[7][5]);

void
letraM (char letra[7][5]);

void
letraN (char letra[7][5]);

void
letraO (char letra[7][5]);

void
letraP (char letra[7][5]);

void
letraQ (char letra[7][5]);

void
letraR (char letra[7][5]);

void
letraS (char letra[7][5]);

void
letraT (char letra[7][5]);

void
letraU (char letra[7][5]);

void
letraW (char letra[7][5]);

void
letraV (char letra[7][5]);

void
letraX (char letra[7][5]);

void
letraY (char letra[7][5]);

void
letraZ (char letra[7][5]);

void
alfabetoASCII (char letra[7][5], char c);
