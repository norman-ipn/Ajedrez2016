#include<stdio.h>

#include <string.h>



int
primera_pantalla (void)

