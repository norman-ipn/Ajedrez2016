#include<stdio.h>
void mostrar_resultados (int num_jugador);
