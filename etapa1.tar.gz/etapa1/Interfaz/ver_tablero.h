void
ver_tablero(char tablero [8][8]);
