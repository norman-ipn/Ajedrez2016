#include <stdio.h>

#include <stdlib.h>

void 
Reloj(int hr, min, seg);

void 
gotoxy (int x, int y);

void
otra_funcion (void);
  
void
inicializar (char tablero[8][8]);


void manual(void);

void iniciar_sesion();

void menu(void);

void
menu_jugador (void);

void
manual (void);


void
iniciar_sesion ();

int
menu2 (void);
 
void modalidad_de_juego ();

void print_row(char board[8][8], int j);

void print(char board[8][8]);
