char
ver_pieza (int pos_i_x, int pos_i_y, int pos_f_x, int pos_f_y,  char tablero[8][8]);
