﻿# Ajedrez2016
En este documento escribiran las dudas, sugerencias, o aportes hechos para el Módulo de redes :D! 
